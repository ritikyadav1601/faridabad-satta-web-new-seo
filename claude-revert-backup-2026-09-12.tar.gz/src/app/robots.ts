import type { MetadataRoute } from "next";
import { SITE_URL } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: "*",
        // Chart pages hydrate their result tables from these read-only routes.
        // Their longer Allow paths override the general /api/ block so search
        // engine renderers can see the same chart content as visitors.
        allow: [
          "/",
          "/api/game-chart",
          "/api/year-chart",
          "/api/custom-games/chart",
        ],
        // "/add-game-value" is intentionally NOT disallowed here: it is
        // noindex + login-gated, and is no longer linked from anywhere on the
        // site, so relying on a single mechanism (noindex) avoids the old
        // conflict where a robots.txt disallow prevented crawlers from ever
        // seeing the noindex tag in the first place.
        disallow: ["/api/"],
      },
    ],
    sitemap: `${SITE_URL}/sitemap.xml`,
    host: SITE_URL,
  };
}
