import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { getAllPublishedBlogs } from "@/lib/blogs-mongodb";
import { SITE_URL } from "@/lib/site";

export const revalidate = 60;

const title = "Blog";
const description =
  "Articles and updates from Faridabad Satta — browse the full archive of published posts.";

export const metadata: Metadata = {
  title, // root layout's "%s | Faridabad Satta" template applies here
  description,
  alternates: { canonical: `${SITE_URL}/blog` },
  openGraph: { type: "website", url: `${SITE_URL}/blog`, title, description },
};

function plainText(content: string) {
  return content
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, " ")
    .trim();
}

export default async function BlogIndexPage() {
  const posts = await getAllPublishedBlogs();
  const breadcrumbData = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Blog", item: `${SITE_URL}/blog` },
    ],
  };

  return (
    <main className="mx-auto max-w-6xl px-3 py-8 sm:px-5 md:py-12">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbData) }}
      />
      <nav aria-label="Breadcrumb" className="mb-4 text-sm text-gray-500">
        <ol className="flex flex-wrap items-center gap-2">
          <li><Link href="/" className="hover:text-blue-700">Home</Link></li>
          <li aria-hidden="true">/</li>
          <li aria-current="page" className="font-semibold text-gray-800">Blog</li>
        </ol>
      </nav>

      <header className="mb-6">
        <h1 className="text-3xl font-black tracking-tight text-gray-900 md:text-4xl">Blog</h1>
        <p className="mt-2 text-gray-600">Every published article, newest first.</p>
      </header>

      {posts.length === 0 ? (
        <p className="rounded-2xl border border-gray-200 bg-white p-6 text-center text-gray-500">
          No blog posts published yet.
        </p>
      ) : (
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => {
            const content = plainText(post.content);
            const previewLength = 160;
            const preview =
              content.length > previewLength ? `${content.slice(0, previewLength).trimEnd()}…` : content;

            return (
              <Link
                key={post.id}
                href={`/blog/${encodeURIComponent(post.slug)}`}
                className="group block overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm transition duration-200 hover:-translate-y-1 hover:border-amber-300 hover:shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[var(--color-brand-deep)]"
              >
                <article>
                  {post.image && (
                    <div className="relative h-48 w-full">
                      <Image
                        src={post.image}
                        alt={post.title}
                        fill
                        sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
                        loading="lazy"
                        className="object-cover transition duration-300 group-hover:scale-[1.03]"
                      />
                    </div>
                  )}
                  <div className="p-5 md:p-6">
                    {post.createdAt && (
                      <time
                        className="text-xs font-semibold uppercase tracking-wide text-gray-400"
                        dateTime={post.createdAt}
                      >
                        {new Intl.DateTimeFormat("en-IN", {
                          timeZone: "Asia/Kolkata",
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        }).format(new Date(post.createdAt))}
                      </time>
                    )}
                    <h2 className="mt-2 text-xl font-black text-gray-900 transition group-hover:text-amber-700">
                      {post.title}
                    </h2>
                    {preview && (
                      <p className="mt-3 whitespace-pre-line text-sm leading-6 text-gray-600">{preview}</p>
                    )}
                  </div>
                </article>
              </Link>
            );
          })}
        </div>
      )}
    </main>
  );
}
