import Link from "next/link";

export default function NotFound() {
  return (
    <main className="min-h-[70vh] bg-[var(--surface-page)] flex items-center justify-center px-4 py-16">
      <div className="mx-auto max-w-xl rounded-2xl border border-gray-200 bg-white p-8 text-center shadow-sm md:p-10">
        <p className="text-sm font-bold uppercase tracking-wider text-indigo-600">404</p>
        <h1 className="mt-2 text-3xl font-black tracking-tight text-gray-900 md:text-4xl">
          Page not found
        </h1>
        <p className="mt-4 leading-7 text-gray-600">
          The page you&apos;re looking for doesn&apos;t exist, may have moved, or the game/date
          you requested isn&apos;t available.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/"
            className="rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-indigo-700"
          >
            Go to Home
          </Link>
          <Link
            href="/charts"
            className="rounded-xl border border-gray-200 bg-white px-5 py-2.5 text-sm font-bold text-gray-800 transition hover:border-indigo-300 hover:bg-indigo-50"
          >
            Browse Charts
          </Link>
        </div>
      </div>
    </main>
  );
}
