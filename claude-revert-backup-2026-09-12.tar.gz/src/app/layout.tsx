import type { Metadata } from "next";
import Script from "next/script";
import "./globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { WhatsAppButton } from "@/components/layout/WhatsAppButton";
import { LanguageProvider } from "@/context/LanguageContext";
import { SITE_NAME, SITE_URL } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default:
      "Faridabad Satta Result | Live Results, Charts & Old Records",
    template: `%s | ${SITE_NAME}`,
  },
  description:
    "Check Faridabad Satta results, daily charts and historical records for Faridabad, Gali, Desawar, Ghaziabad, Delhi Bazar and more markets. Updated regularly.",
  icons: {
    icon: [{ url: "/favicon.png", type: "image/png" }],
    shortcut: "/favicon.png",
    apple: "/favicon.png",
  },
  verification: {
    google: "iwfZBGPCqdL74ht1H9V0bVgdfHVKvW-qXETMj6c7_Uk",
  },

  openGraph: {
    type: "website",
    locale: "en_IN",
    url: SITE_URL,
    siteName: SITE_NAME,
    title: "Faridabad Satta Result | Live Results, Charts & Old Records",
    description:
      "Live Faridabad Satta results, charts and old records for Faridabad, Gali, Desawar, Ghaziabad and more markets.",
  },
  twitter: {
    card: "summary",
    title: "Faridabad Satta Result | Live Results, Charts & Old Records",
    description:
      "Live Faridabad Satta results, charts and old records for Faridabad and more markets.",
  },
  robots: { index: true, follow: true },
  alternates: { canonical: SITE_URL },
  category: "News and information",
};

const structuredData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "Organization",
      "@id": `${SITE_URL}/#organization`,
      name: SITE_NAME,
      url: SITE_URL,
      description:
        "An independent informational platform for live result updates and historical chart records.",
      inLanguage: "en-IN",
    },
    {
      "@type": "WebSite",
      "@id": `${SITE_URL}/#website`,
      name: SITE_NAME,
      url: SITE_URL,
      inLanguage: "en-IN",
      publisher: { "@id": `${SITE_URL}/#organization` },
      potentialAction: {
        "@type": "ReadAction",
        target: SITE_URL,
      },
    },
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className="h-full antialiased"
    >
      <body className="min-h-full flex flex-col">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
        {/* Loaded via next/script (afterInteractive) instead of a raw <head>
            script tag so Google Tag Manager never competes with the initial
            page render for main-thread time. */}
        <Script
          async
          src="https://www.googletagmanager.com/gtag/js?id=G-W71W8KSGT4"
          strategy="afterInteractive"
        />
        <Script id="ga-init" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-W71W8KSGT4');
          `}
        </Script>
        <LanguageProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
          <WhatsAppButton />
        </LanguageProvider>
      </body>
    </html>
  );
}
