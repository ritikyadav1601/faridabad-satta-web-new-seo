import ChartClient, { type MonthColumn } from "./ChartClient";
import { fetchGameChartDataForSSR } from "@/lib/chart-ssr-data";
import { getCachedHomeData } from "@/lib/home-data";

interface ChartRow {
  date: string;
  result: string;
}

// `date` may be a plain day number ("26") or a full date string
// (e.g. "2026-06-01"). Always show the day-of-month, never the year.
function getDayOfMonth(date: string): string {
  const trimmed = (date || "").trim();
  if (/^\d{1,2}$/.test(trimmed)) return trimmed;
  const parsed = new Date(trimmed);
  if (!isNaN(parsed.getTime())) return String(parsed.getDate());
  return trimmed.slice(-2);
}

const MONTH_NAMES = ["january","february","march","april","may","june","july","august","september","october","november","december"];
const MONTH_LABELS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
const MONTHS_IN_VIEW = 6;

function getMonthsWindow(anchor: Date, count: number): Date[] {
  const list: Date[] = [];
  for (let i = count - 1; i >= 0; i--) {
    list.push(new Date(anchor.getFullYear(), anchor.getMonth() - i, 1));
  }
  return list;
}

async function fetchMonthForSSR(
  date: Date,
  gameCode: string
): Promise<MonthColumn> {
  const m = MONTH_NAMES[date.getMonth()];
  const y = date.getFullYear();
  const key = `${y}-${date.getMonth()}`;
  const label = `${MONTH_LABELS[date.getMonth()]} ${y}`;

  const data = await fetchGameChartDataForSSR(gameCode, m, String(y));

  const rowsByDay: Record<number, string> = {};
  (data?.results || []).forEach((row: ChartRow) => {
    const day = parseInt(getDayOfMonth(row.date), 10);
    if (!isNaN(day)) rowsByDay[day] = row.result;
  });

  return { key, year: y, monthIndex: date.getMonth(), label, rowsByDay, loaded: true };
}

// Finds the "Result Time: HH:MM" line shown under the game name by matching
// the gameCode slug against the same live/next/rest/sk24 game lists the
// homepage already fetches (and caches for 20s) — mirrors the client-side
// lookup that previously ran across four API calls after mount.
async function fetchResultTimeForSSR(gameCode: string): Promise<string> {
  try {
    const homeData = await getCachedHomeData();
    const games = [
      ...homeData.liveResults,
      ...homeData.nextResults,
      ...homeData.restResults,
      ...homeData.sk24Games,
    ];
    const found = games.find(
      (game) => game.name.toLowerCase().replace(/\s+/g, "-") === gameCode
    );
    return found?.time || "";
  } catch {
    return "";
  }
}

export default async function GameChartPage({
  params,
}: {
  params: Promise<{ gameCode: string }>;
}) {
  const { gameCode } = await params;
  const gameName = gameCode.replace(/-/g, " ").toUpperCase();

  const now = new Date();
  const anchorDate = new Date(now.getFullYear(), now.getMonth());
  const months = getMonthsWindow(anchorDate, MONTHS_IN_VIEW);

  const [initialColumns, initialResultTime] = await Promise.all([
    Promise.all(months.map((date) => fetchMonthForSSR(date, gameCode))),
    fetchResultTimeForSSR(gameCode),
  ]);

  return (
    <ChartClient
      gameCode={gameCode}
      gameName={gameName}
      initialResultTime={initialResultTime}
      initialAnchorYear={anchorDate.getFullYear()}
      initialAnchorMonth={anchorDate.getMonth()}
      initialColumns={initialColumns}
    />
  );
}

// Chart data changes at most a few times a day; revalidate periodically so
// the server-rendered HTML crawlers see stays fresh without hitting the
// scrapers/DB on every single request.
export const revalidate = 300;
