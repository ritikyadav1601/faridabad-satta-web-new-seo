import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { SITE_URL } from "@/lib/site";
import { TOP_GAME_DEFS } from "@/lib/top-games";
import { isMongoTopGameSlug } from "@/lib/top-games-mongodb";

// Per-game SEO metadata for chart pages, keyed by URL slug (gameCode).
const CHART_META: Record<string, { title: string; description: string }> = {
  faridabad: {
    title: "Faridabad Result Chart & Old Records",
    description:
      "Check Faridabad results, daily chart records and historical data on Faridabad Satta.",
  },
  ghaziabad: {
    title: "Ghaziabad Result Chart & Old Records",
    description:
      "Check Ghaziabad results, daily chart records and historical data on Faridabad Satta.",
  },
  gali: {
    title: "Gali Result Chart & Old Records",
    description:
      "Check Gali results, daily chart records and historical data on Faridabad Satta.",
  },
  deshawer: {
    title: "Deshawer Result Chart & Old Records",
    description:
      "Check Deshawer results, daily chart records and historical data on Faridabad Satta.",
  },
  "new-gali": {
    title: "New Gali Satta King Chart",
    description:
      "Check the latest New Gali Satta King chart, daily results, old record, and complete chart history on Faridabad Satta.",
  },
  "delhi-evening": {
    title: "Delhi Evening Satta King Chart",
    description:
      "View Delhi Evening Satta King chart with today's result, old records, and complete historical data.",
  },
  "choti-gali": {
    title: "Choti Gali Satta King Chart",
    description:
      "Find Choti Gali Satta King chart, live results, old charts, and historical records updated daily.",
  },
  desawer: {
    title: "Desawer Satta King Chart",
    description:
      "Check Desawer Satta King chart, daily results, old charts, and complete record history.",
  },
  "shiv-dham": {
    title: "Shiv Dham Satta King Chart",
    description:
      "View Shiv Dham Satta King chart with today's results, historical records, and daily updates.",
  },
  "pushkar-bazar": {
    title: "Pushkar Bazar Satta King Chart",
    description:
      "Get the latest Pushkar Bazar Satta King chart, old records, and daily result updates.",
  },
  "delhi-metro": {
    title: "Delhi Metro Satta King Chart",
    description:
      "Delhi Metro Satta King chart with today's result, old charts, and complete historical records.",
  },
  "shri-sayam": {
    title: "Shri Sayam Satta King Chart",
    description:
      "Check Shri Sayam Satta King chart, historical records, and today's updated results.",
  },
  kolmbia: {
    title: "Kolmbia Satta King Chart",
    description:
      "View Kolmbia Satta King chart with daily results, old charts, and complete chart history.",
  },
  "makka-madina": {
    title: "Makka Madina Satta King Chart",
    description:
      "Find Makka Madina Satta King chart, latest results, old records, and complete history.",
  },
  "kalka-night": {
    title: "Kalka Night Satta King Chart",
    description:
      "Kalka Night Satta King chart featuring today's result, old records, and chart history.",
  },
  "shirdi-dham": {
    title: "Shirdi Dham Satta King Chart",
    description:
      "View Shirdi Dham Satta King chart with updated results, historical charts, and daily records.",
  },
  "delhi-darbar": {
    title: "Delhi Darbar Satta King Chart",
    description:
      "Delhi Darbar Satta King chart with latest results, old records, and complete chart history.",
  },
  kaliyar: {
    title: "Kaliyar Satta King Chart",
    description:
      "Check Kaliyar Satta King chart, daily results, historical records, and old charts.",
  },
  "new-ganga": {
    title: "New Ganga Satta King Chart",
    description:
      "New Ganga Satta King chart with today's results, old records, and complete history.",
  },
  fatehabad: {
    title: "Fatehabad Satta King Chart",
    description:
      "View Fatehabad Satta King chart, daily results, old records, and updated chart history.",
  },
  "shakti-peeth": {
    title: "Shakti Peeth Satta King Chart",
    description:
      "Find Shakti Peeth Satta King chart, latest results, historical charts, and daily updates.",
  },
  "mandi-bazar": {
    title: "Mandi Bazar Satta King Chart",
    description:
      "Mandi Bazar Satta King chart with today's result, old records, and complete history.",
  },
  "ghaziabad-king": {
    title: "Ghaziabad King Satta King Chart",
    description:
      "Check Ghaziabad King Satta King chart, historical records, and today's updated results.",
  },
  "mathura-city": {
    title: "Mathura Satta King Chart",
    description:
      "View Mathura Satta King chart with daily results, old charts, and complete record history.",
  },
  "shiv-ganga": {
    title: "Shiv Ganga Result Chart & Old Records",
    description:
      "Check Shiv Ganga results, daily chart records and historical data on Faridabad Satta.",
  },
  "sabar-bazar": {
    title: "Sabar Bazar Result Chart & Old Records",
    description:
      "Check Sabar Bazar results, daily chart records and historical data on Faridabad Satta.",
  },
  alinagar: {
    title: "Alinagar Result Chart & Old Records",
    description:
      "Check Alinagar results, daily chart records and historical data on Faridabad Satta.",
  },
  "delhi-bazar": {
    title: "Delhi Bazar Result Chart & Old Records",
    description:
      "Check Delhi Bazar results, daily chart records and historical data on Faridabad Satta.",
  },
  "shri-ganesh": {
    title: "Shri Ganesh Result Chart & Old Records",
    description:
      "Check Shri Ganesh results, daily chart records and historical data on Faridabad Satta.",
  },
  "fatehabad-city": {
    title: "Fatehabad City Result Chart & Old Records",
    description:
      "Check Fatehabad City results, daily chart records and historical data on Faridabad Satta.",
  },
  "multan-bazar": {
    title: "Multan Bazar Result Chart & Old Records",
    description:
      "Check Multan Bazar results, daily chart records and historical data on Faridabad Satta.",
  },
  kalyanpuri: {
    title: "Kalyanpuri Result Chart & Old Records",
    description:
      "Check Kalyanpuri results, daily chart records and historical data on Faridabad Satta.",
  },
  kohlapur: {
    title: "Kohlapur Satta King Chart",
    description:
      "Check Kohlapur Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.",
  },
  manipur: {
    title: "Manipur Satta King Chart",
    description:
      "Check Manipur Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.",
  },
  "up-bazar": {
    title: "UP Bazar Satta King Chart",
    description:
      "Check UP Bazar Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.",
  },
  "palwal-city": {
    title: "Palwal City Satta King Chart",
    description:
      "Check Palwal City Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.",
  },
};

function titleCase(slug: string): string {
  return slug
    .replace(/-/g, " ")
    .split(" ")
    .filter(Boolean)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

function canonicalGameCode(gameCode: string): string {
  const aliases: Record<string, string> = {
    fridabad: "faridabad",
    frbd: "faridabad",
    gaziabad: "ghaziabad",
    gzbd: "ghaziabad",
    "purani-gali": "gali",
    disawar: "deshawer",
    desawar: "deshawer",
    desawer: "deshawer",
    dswr: "deshawer",
  };
  return aliases[gameCode.toLowerCase()] || gameCode.toLowerCase();
}

function isJunkGameCode(gameCode: string): boolean {
  return gameCode.toLowerCase().replace(/[^a-z0-9]/g, "") === "showyourgamehere";
}

// Games that always exist regardless of what MongoDB returns. Mirrors the
// extra custom-game entries in FIXED_GAME_NAMES (src/app/sitemap.ts) and
// customGameKeys (src/app/chart/[gameCode]/page.tsx) — keep these three in
// sync if a custom game is ever added or removed.
const CUSTOM_GAME_SLUGS = ["kohlapur", "manipur", "up-bazar", "palwal-city", "mathura-city"];

// Every slug this route will serve a real chart for: every TOP_GAME_DEFS
// game, every fixed custom game, and everything with curated CHART_META
// (CHART_META already covers several live/SK24 games beyond TOP_GAME_DEFS).
//
// This is intentionally a static, database-free check — no live MongoDB
// lookup here. A game the scraper newly discovers in MongoDB (see
// src/lib/scraper.ts / src/lib/extra-games-mongodb.ts) won't 200 on this
// route until its slug is added below (or to CHART_META), the same way it
// already needs a manual CHART_META entry to get non-generic metadata.
// That's a deliberate trade-off: keeping this route free of any database
// call means a MongoDB outage can never turn a legitimate chart page into
// a 500, which matters far more than same-day coverage of a brand-new slug.
const STATIC_KNOWN_SLUGS = new Set<string>([
  ...TOP_GAME_DEFS.map((game) => canonicalGameCode(game.name.replace(/\s+/g, "-"))),
  ...CUSTOM_GAME_SLUGS,
  ...Object.keys(CHART_META),
]);

// Static slugs resolve instantly with no DB round trip (the common case).
// Anything else falls through to a live check against the `cities`
// collection (covers every active AND inactive promoted game, so a game an
// admin demotes to "Other Games" keeps a working, indexable chart page
// instead of 404ing) — a MongoDB outage there just means new/demoted games
// temporarily behave like before this change, never a 500.
async function isKnownGameCode(canonicalCode: string): Promise<boolean> {
  if (STATIC_KNOWN_SLUGS.has(canonicalCode)) return true;
  return isMongoTopGameSlug(canonicalCode);
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ gameCode: string }>;
}): Promise<Metadata> {
  const { gameCode } = await params;
  const canonicalCode = canonicalGameCode(gameCode);

  if (isJunkGameCode(gameCode) || !(await isKnownGameCode(canonicalCode))) {
    return {
      title: "Chart Not Found",
      robots: { index: false, follow: true },
    };
  }

  const meta = CHART_META[canonicalCode];
  const name = titleCase(canonicalCode);
  const title = meta?.title ?? `${name} Satta King Chart`;
  const description =
    meta?.description ??
    `Check the ${name} Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.`;

  const url = `${SITE_URL}/chart/${encodeURIComponent(canonicalCode)}`;

  return {
    title,
    description,
    alternates: { canonical: url },
    openGraph: {
      type: "website",
      title,
      description,
      url,
    },
  };
}

export default async function ChartLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ gameCode: string }>;
}) {
  const { gameCode } = await params;
  if (isJunkGameCode(gameCode)) notFound();

  const canonicalCode = canonicalGameCode(gameCode);
  if (!(await isKnownGameCode(canonicalCode))) notFound();

  const name = titleCase(canonicalCode);
  const url = `${SITE_URL}/chart/${encodeURIComponent(canonicalCode)}`;
  const breadcrumbData = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Charts", item: `${SITE_URL}/charts` },
      { "@type": "ListItem", position: 3, name: `${name} Chart`, item: url },
    ],
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbData) }}
      />
      {children}
    </>
  );
}
