import { getGameChartCacheFromMongo, getCustomGameDocuments } from "@/lib/extra-games-mongodb";
import { scrapeGameChart, scrapeSattaFastGameChart, scrapeSK24GameChart } from "@/lib/scraper";
import { getTopGameChartFromMongo, isMongoTopGameSlug } from "@/lib/top-games-mongodb";
import { memGet, memSet } from "@/lib/api-helpers";
import type { GameChartData } from "@/lib/types";

// Mirrors the slug normalization in /api/game-chart so the server-rendered
// initial view and the client-side month-navigation API resolve aliases to
// the exact same canonical slug and share the same in-memory cache entries.
const SLUG_ALIASES: Record<string, string> = {
  fridabad: "faridabad",
  frbd: "faridabad",
  gaziabad: "ghaziabad",
  gzbd: "ghaziabad",
  disawar: "desawar",
  desawer: "desawar",
  dswr: "desawar",
};

const SATTA_FAST_SLUGS = new Set(["delhi-bazar", "shri-ganesh"]);

/**
 * Server-side chart data fetch used to render the initial `/chart/[gameCode]`
 * view in the server-rendered HTML (see src/app/chart/[gameCode]/page.tsx).
 *
 * This intentionally mirrors /api/game-chart's lookup order (same cache key,
 * same source priority) rather than importing that route handler, so the
 * existing API route used for client-side month pagination is left
 * completely untouched. Unlike the route, this never throws or returns a
 * 500 — any failure (including MongoDB being unreachable) resolves to
 * `null` so a single flaky external call can't take the whole page down,
 * the same resilience fix already applied to getKhaiwalSettings().
 */
export async function fetchGameChartDataForSSR(
  rawSlug: string,
  month?: string,
  year?: string
): Promise<GameChartData | null> {
  try {
    const slug = SLUG_ALIASES[rawSlug.toLowerCase()] || rawSlug.toLowerCase();
    const cacheKey = `game:${slug}:${month || "current"}:${year || "current"}`;

    const cached = memGet<GameChartData>(cacheKey);
    if (cached) return cached;

    if (SATTA_FAST_SLUGS.has(slug)) {
      try {
        const sourceResult = await scrapeSattaFastGameChart(slug, month, year);
        if (sourceResult) {
          const chartData: GameChartData = { ...sourceResult, scrapedAt: Date.now() };
          memSet(cacheKey, chartData, 300);
          return chartData;
        }
      } catch (error) {
        console.error("[chart-ssr] satta-fast scrape failed:", (error as Error).message);
      }
    }

    if (await isMongoTopGameSlug(slug)) {
      const mongoData = await getTopGameChartFromMongo(slug, month || "", year || "");
      if (mongoData) {
        memSet(cacheKey, mongoData, 300);
        return mongoData;
      }
    }

    const mongoCacheData = await getGameChartCacheFromMongo(slug, month, year);
    if (mongoCacheData) {
      memSet(cacheKey, mongoCacheData, 300);
      return mongoCacheData;
    }

    let result = await scrapeGameChart(slug, month, year);
    if (!result) {
      result = await scrapeSK24GameChart(slug, month, year);
    }
    if (!result) return null;

    const chartData: GameChartData = { ...result, scrapedAt: Date.now() };
    memSet(cacheKey, chartData, 300);
    return chartData;
  } catch (error) {
    console.error("[chart-ssr] fetchGameChartDataForSSR failed:", (error as Error).message);
    return null;
  }
}

export interface CustomGameMonthResult {
  gameName: string;
  chartTitle: string;
  month: string;
  year: string;
  columns: string[];
  results: { date: string; day: string; result: string }[];
}

const MONTH_NAMES_FULL = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

/**
 * Server-side equivalent of /api/custom-games/chart's GET handler, used to
 * render the initial view for custom games (kohlapur, manipur, up-bazar,
 * palwal-city, mathura-city). The API route itself is left untouched; it
 * keeps serving client-side month navigation exactly as before.
 */
export async function fetchCustomGameChartMonthForSSR(
  game: string,
  month: number,
  year: number
): Promise<CustomGameMonthResult | null> {
  try {
    const cacheKey = `custom-chart:${game}:${year}:${month}`;
    const cached = memGet<CustomGameMonthResult>(cacheKey);
    if (cached) return cached;

    const endDate = new Date(year, month, 0); // last day of month
    const daysInMonth = endDate.getDate();

    const startStr = `${year}-${String(month).padStart(2, "0")}-01`;
    const endStr = `${year}-${String(month).padStart(2, "0")}-${String(daysInMonth).padStart(2, "0")}`;

    const documents = await getCustomGameDocuments(startStr, endStr);

    const dataMap: Record<string, string> = {};
    documents.forEach((data) => {
      if (data[game]) {
        dataMap[String(data._id)] = String(data[game]);
      }
    });

    const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const results: { date: string; day: string; result: string }[] = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dateObj = new Date(year, month - 1, d);
      const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      results.push({
        date: String(d).padStart(2, "0"),
        day: dayNames[dateObj.getDay()],
        result: dataMap[dateStr] || "XX",
      });
    }

    const payload: CustomGameMonthResult = {
      gameName: game.replace(/-/g, " ").toUpperCase(),
      chartTitle: `${game.replace(/-/g, " ").toUpperCase()} - ${MONTH_NAMES_FULL[month - 1]} ${year}`,
      month: MONTH_NAMES_FULL[month - 1],
      year: String(year),
      columns: ["Date", "Day", "Result"],
      results,
    };
    memSet(cacheKey, payload, 300);
    return payload;
  } catch (error) {
    console.error("[chart-ssr] fetchCustomGameChartMonthForSSR failed:", (error as Error).message);
    return null;
  }
}
