import { MongoClient } from "mongodb";
import { getISTDateString } from "./utils";
import { EMPTY_TOP_GAMES, TOP_GAME_DEFS } from "./top-games";
import type { ChartRow, GameChartData, MonthlyChartData, SK24Game } from "./types";

let clientPromise: Promise<MongoClient> | null = null;
let mongoUnavailableUntil = 0;
let cityNamesCache: { data: Map<string, string>; expiresAt: number } | null = null;
let cityNamesPromise: Promise<Map<string, string>> | null = null;
const MONGO_RETRY_DELAY_MS = 30_000;
const CITY_CACHE_TTL_MS = 6 * 60 * 60 * 1000;

function isMongoConnectivityError(error: unknown) {
  const details = [
    error instanceof Error ? error.message : String(error),
    String((error as { code?: unknown })?.code ?? ""),
    String((error as { cause?: unknown })?.cause ?? ""),
  ].join(" ");

  return /ECONNREFUSED|ENOTFOUND|ETIMEDOUT|querySrv|server selection|MongoNetworkError|MongoServerSelectionError/i.test(details);
}

function reportMongoReadFailure(operation: string, error: unknown) {
  // Atlas/DNS can be temporarily unavailable. All callers already provide safe
  // fallback data, so expected connectivity failures should not be forwarded by
  // React Server Components into the browser console as application errors.
  if (isMongoConnectivityError(error)) return;
  console.error(`[top-games-mongodb] Failed to ${operation}:`, error);
}

function getClient() {
  const uri = process.env.TOP_GAMES_MONGODB_URI;
  if (!uri || Date.now() < mongoUnavailableUntil) return null;

  if (!clientPromise) {
    clientPromise = new MongoClient(uri, { serverSelectionTimeoutMS: 5000 }).connect();
    clientPromise.catch(() => {
      mongoUnavailableUntil = Date.now() + MONGO_RETRY_DELAY_MS;
      clientPromise = null;
    });
  }
  return clientPromise;
}

function normalise(value: unknown) {
  return String(value || "").toLowerCase().replace(/[^a-z0-9]/g, "");
}

function resultValue(record: Record<string, unknown>) {
  const value = record.result ?? record.today ?? record.value ?? record.number;
  return value === undefined || value === null || value === "" ? "XX" : String(value).padStart(2, "0");
}

function dateKey(value: unknown) {
  if (value instanceof Date) {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: "Asia/Kolkata",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).formatToParts(value);
    const part = (type: string) => parts.find((item) => item.type === type)?.value || "";
    return `${part("year")}-${part("month")}-${part("day")}`;
  }
  return String(value ?? "").slice(0, 10);
}

function monthRangeInIST(year: number, monthIndex: number) {
  const start = new Date(
    `${year}-${String(monthIndex + 1).padStart(2, "0")}-01T00:00:00+05:30`
  );
  const nextYear = monthIndex === 11 ? year + 1 : year;
  const nextMonth = monthIndex === 11 ? 1 : monthIndex + 2;
  const end = new Date(
    `${nextYear}-${String(nextMonth).padStart(2, "0")}-01T00:00:00+05:30`
  );
  return { start, end };
}

// ─────────────────────────────────────────────────────────────────────────
// The `cities` collection (admin-dashboard DB) holds every game the admin
// dashboard manages. TOP_GAME_DEFS stays the definitive "Top Games" list at
// the top of the homepage, in that exact order; every OTHER city — whatever
// its `isActive` flag — is surfaced in the "Other Games" section below
// instead of being dropped. `revelationOrder`/`revelationTime` give those
// extra games their ordering and display time, and reading the collection
// here also lets /chart/[slug] recognise them instead of 404ing.
// ─────────────────────────────────────────────────────────────────────────

interface CityGameDef {
  name: string;
  aliases: readonly string[];
  time: string;
  isActive: boolean;
  revelationOrder: number;
}

// A couple of games kept the same identity across a historical rename;
// mapping the DB's current name back to the long-standing display name/URL
// slug keeps old links (e.g. /chart/gali) working.
const LEGACY_NAME_OVERRIDES: Record<string, string> = {
  "PURANI GALI": "GALI",
};

// Extra slug aliases (beyond the plain kebab-case of the name) that should
// keep resolving to each game, mirroring the aliases already hardcoded in
// TOP_GAME_DEFS for these same games.
const LEGACY_ALIASES: Record<string, readonly string[]> = {
  DESHAWER: ["deshawer", "desawar", "desawer", "disawar"],
  FARIDABAD: ["fridabad", "frbd"],
  GHAZIABAD: ["gaziabad", "gzbd"],
  GALI: ["puranigali"],
  "DELHI BAZAR": ["delhibazar", "dlbz"],
  "SHRI GANESH": ["shriganesh", "srgn"],
  "FATEHABAD CITY": ["fatehabadcity"],
  "MULTAN BAZAR": ["multanbazar"],
  "SHIV GANGA": ["shivganga"],
  "SABAR BAZAR": ["sabarbazar"],
};

// Junk/test entries that must never surface anywhere on the site, in either
// the Top Games or Other Games sections (mirrors the hiddenGames list in
// src/app/HomeClient.tsx).
const JUNK_CITY_NAMES = new Set([
  "parascity",
  "agracity",
  "jaipurcity",
  "varindavancity",
  "vrindavancity",
  "showyourgamehere",
]);

// Every name/alias that belongs to the fixed Top Games list, so the extra
// cities can be told apart from it.
const TOP_GAME_KEYS = new Set(
  TOP_GAME_DEFS.flatMap(({ name, aliases }) => [
    name.toLowerCase().replace(/[^a-z0-9]/g, ""),
    ...aliases.map((alias) => alias.toLowerCase().replace(/[^a-z0-9]/g, "")),
  ])
);

function isTopGameDef(def: { name: string; aliases: readonly string[] }): boolean {
  return (
    TOP_GAME_KEYS.has(normalise(def.name)) ||
    def.aliases.some((alias) => TOP_GAME_KEYS.has(normalise(alias)))
  );
}

function formatRevelationTime(time24: string): string {
  const match = /^(\d{1,2}):(\d{2})$/.exec(time24.trim());
  if (!match) return time24;
  let hour = parseInt(match[1], 10);
  const minute = match[2];
  const period = hour >= 12 ? "PM" : "AM";
  hour = hour % 12;
  if (hour === 0) hour = 12;
  return `${String(hour).padStart(2, "0")}:${minute} ${period}`;
}

interface CityDoc {
  _id: string;
  name: string;
  isActive: boolean;
  revelationOrder: number;
  revelationTime: string;
}

let cityDefsCache: { data: CityGameDef[]; expiresAt: number } | null = null;
let cityDefsPromise: Promise<CityGameDef[]> | null = null;

async function getCityGameDefs(db: ReturnType<MongoClient["db"]>): Promise<CityGameDef[]> {
  if (cityDefsCache && cityDefsCache.expiresAt > Date.now()) return cityDefsCache.data;
  if (!cityDefsPromise) {
    cityDefsPromise = db
      .collection<Record<string, unknown>>("cities")
      .find({})
      .project({ name: 1, cityName: 1, isActive: 1, revelationOrder: 1, revelationTime: 1 })
      .toArray()
      .then((docs) => {
        const cities: CityDoc[] = docs.map((doc) => ({
          _id: String(doc._id),
          name: String(doc.name ?? doc.cityName ?? ""),
          isActive: doc.isActive !== false,
          revelationOrder:
            typeof doc.revelationOrder === "number" ? doc.revelationOrder : Number.MAX_SAFE_INTEGER,
          revelationTime: String(doc.revelationTime ?? ""),
        }));

        const data: CityGameDef[] = cities
          .filter((city) => city.name && !JUNK_CITY_NAMES.has(normalise(city.name)))
          .map((city) => {
            const displayName = LEGACY_NAME_OVERRIDES[city.name] || city.name;
            return {
              name: displayName,
              aliases: LEGACY_ALIASES[displayName] || [],
              time: city.revelationTime ? formatRevelationTime(city.revelationTime) : "",
              isActive: city.isActive,
              revelationOrder: city.revelationOrder,
            };
          })
          .sort((a, b) => a.revelationOrder - b.revelationOrder);

        cityDefsCache = { data, expiresAt: Date.now() + CITY_CACHE_TTL_MS };
        return data;
      })
      .finally(() => {
        cityDefsPromise = null;
      });
  }
  return cityDefsPromise;
}

/**
 * Resolves a /chart/[gameCode] slug to its game definition, checking the
 * live `cities` collection first (covers every active AND inactive game,
 * so chart pages for demoted games keep working instead of 404ing) and
 * falling back to the static TOP_GAME_DEFS list if MongoDB is unreachable.
 */
export async function topGameForSlug(
  slug: string
): Promise<{ name: string; time: string; aliases: readonly string[] } | undefined> {
  const wanted = normalise(slug);
  const client = getClient();
  if (client) {
    try {
      const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
      const defs = await getCityGameDefs(db);
      const match = defs.find(({ name, aliases }) =>
        [normalise(name), ...aliases.map(normalise)].includes(wanted)
      );
      if (match) return match;
    } catch (error) {
      reportMongoReadFailure("resolve game slug", error);
    }
  }
  return TOP_GAME_DEFS.find(({ name, aliases }) =>
    [normalise(name), ...aliases.map(normalise)].includes(wanted)
  );
}

export async function isMongoTopGameSlug(slug: string): Promise<boolean> {
  return Boolean(await topGameForSlug(slug));
}

export async function getTopGameAvailableYearsFromMongo(): Promise<Record<string, number[]>> {
  const client = getClient();
  const emptyResult = (names: readonly string[]) =>
    Object.fromEntries(names.map((name) => [name.toLowerCase().replace(/\s+/g, "-"), []]));

  if (!client) return emptyResult(TOP_GAME_DEFS.map(({ name }) => name));

  try {
    const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
    const cityDefs = await getCityGameDefs(db);
    const defs: readonly { name: string; aliases: readonly string[] }[] =
      cityDefs.length ? cityDefs : TOP_GAME_DEFS;
    const available: Record<string, Set<number>> = Object.fromEntries(
      defs.map(({ name }) => [name.toLowerCase().replace(/\s+/g, "-"), new Set<number>()])
    );
    const collection = db.collection<Record<string, unknown>>(
      process.env.TOP_GAMES_MONGODB_COLLECTION || "dailynumbers"
    );
    const [cityNames, rows] = await Promise.all([
      getCityNames(db),
      collection
        .find({ date: { $exists: true } })
        .project({ city: 1, game: 1, date: 1, resultDate: 1 })
        .toArray(),
    ]);

    for (const row of rows) {
      const rawGame = row.city ?? row.game;
      const resolvedName = cityNames.get(String(rawGame)) ?? String(rawGame ?? "");
      const game = defs.find(({ name, aliases }) => {
        const candidates = new Set([normalise(name), ...aliases.map(normalise)]);
        return candidates.has(normalise(resolvedName));
      });
      if (!game) continue;
      const year = Number(dateKey(row.date ?? row.resultDate).slice(0, 4));
      if (Number.isInteger(year) && year >= 2000) {
        available[game.name.toLowerCase().replace(/\s+/g, "-")].add(year);
      }
    }

    return Object.fromEntries(
      Object.entries(available).map(([slug, years]) => [slug, [...years].sort((a, b) => b - a)])
    );
  } catch (error) {
    reportMongoReadFailure("read available years", error);
    return emptyResult(TOP_GAME_DEFS.map(({ name }) => name));
  }
}

/**
 * Every game the sitemap should list a /chart/[slug] (and, where available,
 * /charts/[slug]/[year]) entry for: the full dynamic `cities` list (Top +
 * Other Games), falling back to the static 12-game list if MongoDB can't be
 * reached.
 */
export async function getAllTopGameDefsForSitemap(): Promise<{ name: string }[]> {
  const client = getClient();
  if (!client) return TOP_GAME_DEFS.map(({ name }) => ({ name }));

  try {
    const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
    const cityDefs = await getCityGameDefs(db);
    return cityDefs.length
      ? cityDefs.map(({ name }) => ({ name }))
      : TOP_GAME_DEFS.map(({ name }) => ({ name }));
  } catch (error) {
    reportMongoReadFailure("read city game defs for sitemap", error);
    return TOP_GAME_DEFS.map(({ name }) => ({ name }));
  }
}

async function getCityNames(db: ReturnType<MongoClient["db"]>) {
  if (cityNamesCache && cityNamesCache.expiresAt > Date.now()) return cityNamesCache.data;
  if (!cityNamesPromise) {
    cityNamesPromise = db
      .collection<Record<string, unknown>>("cities")
      .find({})
      .project({ name: 1, cityName: 1 })
      .toArray()
      .then((cities) => {
        const data = new Map(
          cities.map((city) => [String(city._id), String(city.name ?? city.cityName ?? "")])
        );
        cityNamesCache = { data, expiresAt: Date.now() + CITY_CACHE_TTL_MS };
        return data;
      })
      .finally(() => {
        cityNamesPromise = null;
      });
  }
  return cityNamesPromise;
}

/**
 * Reads the promoted games from the separate MongoDB database. Expected document
 * shape: { city: "<city id>", date: Date, number }, with names in the `cities`
 * collection. The older { game, resultDate, result } shape is also supported.
 *
 * "Top Games" is exactly the TOP_GAME_DEFS list, in that order. Every other
 * game in the `cities` collection is surfaced by getOtherCityGamesFromMongo()
 * in the "Other Games" section below instead.
 */
export async function getTopGamesFromMongo(): Promise<SK24Game[]> {
  const client = getClient();
  if (!client) return EMPTY_TOP_GAMES;

  try {
    const dbName = process.env.TOP_GAMES_MONGODB_DB;
    const collectionName = process.env.TOP_GAMES_MONGODB_COLLECTION || "gameresults";
    const db = (await client).db(dbName || undefined);
    const today = getISTDateString();
    const yesterday = getISTDateString(-1);
    const tomorrow = getISTDateString(1);
    const yesterdayStart = new Date(`${yesterday}T00:00:00.000Z`);
    const tomorrowStart = new Date(`${tomorrow}T00:00:00.000Z`);
    const [cityNames, rows] = await Promise.all([
      getCityNames(db),
      db
      .collection<Record<string, unknown>>(collectionName)
      .find({
        // dailynumbers stores `date` as a BSON Date; legacy result collections
        // store resultDate as YYYY-MM-DD strings.
        $or: [
          { resultDate: { $in: [today, yesterday] } },
          { date: { $in: [today, yesterday] } },
          { date: { $gte: yesterdayStart, $lt: tomorrowStart } },
        ],
      })
      .toArray(),
    ]);

    return TOP_GAME_DEFS.map(({ name, time, aliases }) => {
      const gameNames = new Set([normalise(name), ...aliases.map(normalise)]);
      const matching = rows.filter((row) => {
        const game = row.city ?? row.game ?? row.name ?? row.gameName;
        return gameNames.has(normalise(cityNames.get(String(game)) ?? game));
      });
      const todayRow = matching.find((row) => dateKey(row.resultDate ?? row.date) === today);
      const yesterdayRow = matching.find((row) => dateKey(row.resultDate ?? row.date) === yesterday);

      return {
        name,
        time,
        yesterday: yesterdayRow ? resultValue(yesterdayRow) : "XX",
        today: todayRow ? resultValue(todayRow) : "XX",
      };
    });
  } catch (error) {
    reportMongoReadFailure("read top games", error);
    return EMPTY_TOP_GAMES;
  }
}

/**
 * Every game in the `cities` collection that is NOT one of the fixed Top
 * Games — active or not. These belong in the "Other Games" section below the
 * Top Games block, rather than disappearing from the site entirely.
 */
export async function getOtherCityGamesFromMongo(): Promise<SK24Game[]> {
  const client = getClient();
  if (!client) return [];

  try {
    const dbName = process.env.TOP_GAMES_MONGODB_DB;
    const collectionName = process.env.TOP_GAMES_MONGODB_COLLECTION || "gameresults";
    const db = (await client).db(dbName || undefined);
    const today = getISTDateString();
    const yesterday = getISTDateString(-1);
    const tomorrow = getISTDateString(1);
    const yesterdayStart = new Date(`${yesterday}T00:00:00.000Z`);
    const tomorrowStart = new Date(`${tomorrow}T00:00:00.000Z`);
    const [cityNames, cityDefs, rows] = await Promise.all([
      getCityNames(db),
      getCityGameDefs(db),
      db
        .collection<Record<string, unknown>>(collectionName)
        .find({
          $or: [
            { resultDate: { $in: [today, yesterday] } },
            { date: { $in: [today, yesterday] } },
            { date: { $gte: yesterdayStart, $lt: tomorrowStart } },
          ],
        })
        .toArray(),
    ]);

    const otherDefs = cityDefs.filter((def) => !isTopGameDef(def));

    return otherDefs.map(({ name, time, aliases }) => {
      const gameNames = new Set([normalise(name), ...aliases.map(normalise)]);
      const matching = rows.filter((row) => {
        const game = row.city ?? row.game ?? row.name ?? row.gameName;
        return gameNames.has(normalise(cityNames.get(String(game)) ?? game));
      });
      const todayRow = matching.find((row) => dateKey(row.resultDate ?? row.date) === today);
      const yesterdayRow = matching.find((row) => dateKey(row.resultDate ?? row.date) === yesterday);

      return {
        name,
        time,
        yesterday: yesterdayRow ? resultValue(yesterdayRow) : "XX",
        today: todayRow ? resultValue(todayRow) : "XX",
      };
    });
  } catch (error) {
    reportMongoReadFailure("read other city games", error);
    return [];
  }
}

// Monthly chart data for the MongoDB-backed promoted games.
export async function getTopGameChartFromMongo(
  slug: string,
  month: string,
  year: string
): Promise<GameChartData | null> {
  const game = await topGameForSlug(slug);
  const client = getClient();
  if (!game || !client) return null;

  const monthIndex = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"].indexOf(month.toLowerCase());
  const yearNumber = Number(year);
  if (monthIndex < 0 || !Number.isInteger(yearNumber)) return null;

  try {
    const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
    const { start, end } = monthRangeInIST(yearNumber, monthIndex);
    const [cityNames, rows] = await Promise.all([
      getCityNames(db),
      db.collection<Record<string, unknown>>(process.env.TOP_GAMES_MONGODB_COLLECTION || "dailynumbers")
        .find({ date: { $gte: start, $lt: end } })
        .sort({ date: 1 })
        .toArray(),
    ]);
    const gameNames = new Set([normalise(game.name), ...game.aliases.map(normalise)]);
    const results = rows
      .filter((row) => gameNames.has(normalise(cityNames.get(String(row.city ?? row.game)) ?? row.city ?? row.game)))
      .map((row) => {
        const date = dateKey(row.date ?? row.resultDate);
        return {
          date,
          day: new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "UTC" }).format(new Date(`${date}T00:00:00.000Z`)),
          result: resultValue(row),
        };
      });

    return {
      gameName: game.name,
      chartTitle: `${game.name} - ${month.charAt(0).toUpperCase()}${month.slice(1)} ${year}`,
      month: month.charAt(0).toUpperCase() + month.slice(1),
      year,
      columns: ["Date", "Day", game.name],
      results,
      scrapedAt: Date.now(),
    };
  } catch (error) {
    reportMongoReadFailure("read chart", error);
    return null;
  }
}

/** Read a complete year for one promoted game with a single MongoDB query. */
export async function getTopGameYearChartFromMongo(
  slug: string,
  year: number
): Promise<Record<number, Record<number, string>> | null> {
  const game = await topGameForSlug(slug);
  const client = getClient();
  if (!game || !client || !Number.isInteger(year)) return null;

  try {
    const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
    const start = new Date(`${year}-01-01T00:00:00+05:30`);
    const end = new Date(`${year + 1}-01-01T00:00:00+05:30`);
    const [cityNames, rows] = await Promise.all([
      getCityNames(db),
      db.collection<Record<string, unknown>>(process.env.TOP_GAMES_MONGODB_COLLECTION || "dailynumbers")
        .find({ date: { $gte: start, $lt: end } })
        .sort({ date: 1 })
        .toArray(),
    ]);
    const gameNames = new Set([normalise(game.name), ...game.aliases.map(normalise)]);
    const months: Record<number, Record<number, string>> = {};

    for (const row of rows) {
      const rawGame = row.city ?? row.game;
      const resolvedName = cityNames.get(String(rawGame)) ?? String(rawGame ?? "");
      if (!gameNames.has(normalise(resolvedName))) continue;
      const date = dateKey(row.date ?? row.resultDate);
      const monthIndex = Number(date.slice(5, 7)) - 1;
      const day = Number(date.slice(8, 10));
      if (monthIndex < 0 || monthIndex > 11 || day < 1 || day > 31) continue;
      (months[monthIndex] ||= {})[day] = resultValue(row);
    }

    return months;
  } catch (error) {
    reportMongoReadFailure("read yearly chart", error);
    return null;
  }
}

const MONTHLY_CITY_FIELDS: Record<
  string,
  keyof Pick<ChartRow, "dswr" | "frbd" | "gzbd" | "gali" | "srgn" | "dlbz">
> = {
  DESHAWER: "dswr",
  DISAWAR: "dswr",
  FARIDABAD: "frbd",
  GHAZIABAD: "gzbd",
  GAZIABAD: "gzbd",
  GALI: "gali",
  "PURANI GALI": "gali",
  "DELHI BAZAR": "dlbz",
  "SHRI GANESH": "srgn",
};

/**
 * Provides historical rows for the six markets displayed in the monthly chart.
 * Cached extra-games data is merged afterwards only when it provides additional values.
 */
export async function getMonthlyChartFromMongo(
  month: string,
  year: string
): Promise<MonthlyChartData | null> {
  const client = getClient();
  const monthIndex = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"].indexOf(month.toLowerCase());
  const yearNumber = Number(year);
  if (!client || monthIndex < 0 || !Number.isInteger(yearNumber)) return null;

  try {
    const db = (await client).db(process.env.TOP_GAMES_MONGODB_DB || undefined);
    const { start, end } = monthRangeInIST(yearNumber, monthIndex);
    const [cities, rows] = await Promise.all([
      db.collection<Record<string, unknown>>("cities").find({}).project({ name: 1, cityName: 1 }).toArray(),
      db.collection<Record<string, unknown>>(process.env.TOP_GAMES_MONGODB_COLLECTION || "dailynumbers")
        .find({ date: { $gte: start, $lt: end } })
        .sort({ date: 1 })
        .toArray(),
    ]);
    const cityFields = new Map(
      cities.map((city) => [
        String(city._id),
        MONTHLY_CITY_FIELDS[String(city.name ?? city.cityName ?? "").toUpperCase()],
      ])
    );
    const byDay = new Map<number, ChartRow>();

    for (const record of rows) {
      const field = cityFields.get(String(record.city));
      if (!field) continue;
      const date = dateKey(record.date ?? record.resultDate);
      const day = Number(date.slice(-2));
      if (!Number.isInteger(day)) continue;
      const row = byDay.get(day) || {
        date: String(day).padStart(2, "0"),
        dswr: "",
        frbd: "",
        gzbd: "",
        gali: "",
        srgn: "",
        dlbz: "",
      };
      row[field] = resultValue(record);
      byDay.set(day, row);
    }

    if (!byDay.size) return null;
    return {
      month: month.charAt(0).toUpperCase() + month.slice(1).toLowerCase(),
      year: String(yearNumber),
      results: [...byDay.entries()].sort(([a], [b]) => a - b).map(([, row]) => row),
      scrapedAt: Date.now(),
    };
  } catch (error) {
    reportMongoReadFailure("read monthly chart", error);
    return null;
  }
}

export function mergeMonthlyChartData(
  cachedData: MonthlyChartData | null,
  mongoData: MonthlyChartData | null
): MonthlyChartData | null {
  if (!cachedData) return mongoData;
  if (!mongoData) return cachedData;

  const dayFromDate = (date: string) => Number(date.match(/(\d{1,2})$/)?.[1]);
  const rows = new Map<number, ChartRow>();
  cachedData.results.forEach((row) => rows.set(dayFromDate(row.date), { ...row }));
  mongoData.results.forEach((mongoRow) => {
    const day = dayFromDate(mongoRow.date);
    const existing = rows.get(day) || {
      date: mongoRow.date,
      dswr: "",
      frbd: "",
      gzbd: "",
      gali: "",
      srgn: "",
      dlbz: "",
    };
    (["dswr", "frbd", "gzbd", "gali", "srgn", "dlbz"] as const).forEach((field) => {
      if (mongoRow[field]) existing[field] = mongoRow[field];
    });
    rows.set(day, existing);
  });

  return {
    ...cachedData,
    results: [...rows.entries()].sort(([a], [b]) => a - b).map(([, row]) => row),
    scrapedAt: Math.max(cachedData.scrapedAt, mongoData.scrapedAt),
  };
}
