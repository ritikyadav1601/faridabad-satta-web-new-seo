# FaridabadSatta.com — Technical + SEO Code Audit (Full Checklist)

**Scope:** Local Next.js source only. No live-site access, no crawling, no gambling-functionality changes. Audit only — nothing below has been applied.
**Stack:** Next.js 16.2.6 (App Router), React 19.2.4, MongoDB, PM2 on a Hostinger VPS.
**Date:** 2026-09-10

---

## Quick-reference: your 22 checklist items

| # | Item | Status |
|---|---|---|
| 1 | Google indexing | Issue — see #1, #2 |
| 2 | "Discovered – currently not indexed" | Likely driven by #1 and #2 (root causes below) |
| 3 | Crawlability | Issue — see #2, #3 |
| 4 | Server-side rendering | Issue — see #1 |
| 5 | App Router architecture | Issue — see #1 (data-fetching pattern inconsistent between routes) |
| 6 | Metadata | Mostly good — one gap, see #6 |
| 7 | Canonical URLs | Pass, one nit — see #7 |
| 8 | robots.txt | Issue — see #3 |
| 9 | sitemap.xml | Pass, one nit — see #7 |
| 10 | Internal linking | Issue — see #3, #5 |
| 11 | 404/410 handling | Issue — see #2, #4 |
| 12 | Redirects | Pass — see "What's already solid" |
| 13 | noindex/index directives | Issue — see #3 |
| 14 | Duplicate/thin pages | Issue — see #2, #6 |
| 15 | Structured data | Mostly good — one gap, see #8 |
| 16 | Core Web Vitals | Issue — see #9 |
| 17 | Image optimization | Issue — see #9 |
| 18 | JavaScript rendering | Issue — see #1 |
| 19 | API-dependent page content | Issue — see #1 |
| 20 | Page speed | Issue — see #9 |
| 21 | Orphan pages | Issue — see #5 |
| 22 | URL structure | Pass, one nit — see #10 |

---

## Issue #1 — Chart pages render nothing but a loading skeleton server-side

**Severity:** Critical
**Files:** `src/app/chart/[gameCode]/page.tsx`, `src/app/charts/[gameCode]/[year]/page.tsx`
**Checklist items:** 1, 2, 4, 5, 18, 19

**Exact problem:** Both files start with `"use client"` and fetch their entire results table inside `useEffect` → `fetch("/api/game-chart...")` / `fetch("/api/year-chart...")`. The server-rendered HTML for these routes contains only the breadcrumb nav, the `<h1>`, and a skeleton (`Array.from({ length: 12 }).map(...)`). Compare with `src/app/page.tsx`, which is a server component that does `const initialData = await getCachedHomeData()` before rendering — the correct pattern, already used elsewhere in this same codebase.

**Why it affects SEO/indexing:** These are your highest page-count route (one per game, one per game-per-year) and the ones actually meant to rank for date/result queries. When Googlebot's first crawl wave fetches the raw HTML, it sees no table data at all — just a heading and a loading placeholder. It has to queue the page for a second, JS-rendering pass (which is slower, rate-limited, and not guaranteed to happen promptly or at all for lower-priority URLs), and non-Google crawlers (Bing, most AI answer engines, link-preview bots) frequently skip JS rendering entirely and only ever see the empty shell. This exact pattern — real content behind a client fetch — is one of the most common causes of "Crawled – currently not indexed" and "Discovered – currently not indexed" in Search Console, because Google's algorithmic assessment of the *un-rendered* HTML often already scores the page as thin before the rendered pass even happens.

**Recommended fix:** Convert both to server components that fetch data directly (server-side function call, not a `fetch` to your own `/api/...` route) before returning JSX, matching `src/app/page.tsx`'s pattern. Keep only the interactive bits (month/year navigation) as a small client child that receives the initially-rendered data as props and calls the API solely for subsequent navigation.

**Minimal code change (`chart/[gameCode]/page.tsx`):**
```tsx
// Before: "use client" + useEffect fetch
// After:
export const revalidate = 60;

export default async function GameChartPage({ params }: { params: Promise<{ gameCode: string }> }) {
  const { gameCode } = await params;
  const initialColumns = await getInitialChartWindow(gameCode); // new server-side helper, same logic fetchMonth() already has, minus the fetch() round-trip
  return <GameChartClient gameCode={gameCode} initialColumns={initialColumns} />;
}
```
`GameChartClient` becomes the existing component body, but seeded from `initialColumns` instead of starting `columns` at `[]`. The `/api/game-chart` and `/api/year-chart` endpoints stay as-is for client-side month/year paging beyond the initial view.

---

## Issue #2 — `/chart/[gameCode]` has no allow-list: any string is a valid, indexable 200 page

**Severity:** Critical
**File:** `src/app/chart/[gameCode]/layout.tsx`
**Checklist items:** 1, 2, 3, 11, 14

**Exact problem:** `canonicalGameCode()` only rewrites a handful of known aliases and otherwise returns `gameCode.toLowerCase()` unchanged — it never checks the value against a known-games list. `isJunkGameCode()` only filters out the literal string `"showyourgamehere"`. So `/chart/asjdklasjd`, `/chart/xyz123`, `/chart/anything-at-all` all pass straight through, get a `200` response, and get metadata generated on the fly: `title: ${titleCase(canonicalCode)} Satta King Chart`, a templated description, and — critically — **no `noindex`**. Contrast this with `src/app/charts/[gameCode]/[year]/layout.tsx`, which correctly validates `gameCode` against `TOP_GAME_DEFS` and calls `notFound()` (plus sets `robots: { index: false }` in the fallback metadata) for anything that doesn't match. The yearly-archive route did this correctly; the plain chart route didn't.

**Why it affects SEO/indexing:** This is an unbounded, crawlable, indexable URL space returning near-identical thin content (a table that says "No chart data available" for anything not a real game) with auto-generated, formulaic titles/descriptions that differ only by the slug's title-cased text. This is precisely the pattern Google's systems are tuned to detect and deprioritize — and once a domain accumulates enough of these, it doesn't just skip those URLs, it starts crawling the *whole domain* more conservatively, which is a textbook mechanism behind widespread "Discovered – currently not indexed" across otherwise-legitimate pages on the same site. Your own sitemap only ever lists real slugs, so you're not seeding this yourself — but any stray internal link with a typo, a scraped/mirrored copy of your site, or an inbound spam link handing Google an arbitrary `/chart/*` URL is enough to start populating this space, and there's currently nothing stopping it once found.

**Recommended fix:** Validate `gameCode` against a real known-games list (the same source `sitemap.ts` already builds from — `TOP_GAME_DEFS` plus whatever the Mongo-backed homepage/SK24 game names resolve to) and `notFound()` on anything else, exactly like the yearly-archive route already does.

**Minimal code change:**
```tsx
// src/app/chart/[gameCode]/layout.tsx
import { notFound } from "next/navigation";
// ... existing CHART_META, titleCase, canonicalGameCode ...

function isKnownGameCode(canonicalCode: string): boolean {
  return canonicalCode in CHART_META || /* also allow the custom-game keys and any live Mongo-derived slugs you consider valid */ false;
}

export default async function ChartLayout({ children, params }: { ... }) {
  const { gameCode } = await params;
  if (isJunkGameCode(gameCode)) notFound();
  const canonicalCode = canonicalGameCode(gameCode);
  if (!isKnownGameCode(canonicalCode)) notFound();
  // ...unchanged...
}
```
If the live-game list can't be reduced to a static check cheaply inside a layout, at minimum fall back to `notFound()` when the slug isn't in `CHART_META` *and* isn't one of the known custom-game keys — that alone closes the arbitrary-string hole for the vast majority of junk input, since `CHART_META` is your curated, finite list.

---

## Issue #3 — Admin route is both internally linked and doubly (conflictingly) protected

**Severity:** High
**Files:** `src/components/layout/Footer.tsx`, `src/app/robots.ts`, `src/app/add-game-value/layout.tsx`
**Checklist items:** 3, 8, 10, 13

**Exact problem:**
1. `Footer.tsx` links `/add-game-value` ("Admin Panel") from every page on the site.
2. `robots.ts` disallows `/add-game-value` via `robots.txt`.
3. `add-game-value/layout.tsx` also sets `metadata.robots = { index: false, follow: false }`.

Combining (2) and (3) is the actual bug: a `robots.txt` disallow prevents crawling, which means Google never fetches the page and therefore never sees the `noindex` tag in (3) — the two directives fight each other instead of reinforcing. Combined with (1), the URL is guaranteed to be discovered via an internal link on every single page.

**Why it affects SEO/indexing:** A URL that's linked-to-but-disallowed can still appear in Google's index as a bare URL with no title/snippet ("No information is available for this page") if Google decides the link signal is strong enough — which a site-wide footer link is. That's an indexed URL you don't want indexed, and it publicly signals the existence of your admin login on a page every visitor and every crawler sees.

**Recommended fix:** Remove the footer link (the login page doesn't need public in-site navigation — you or your team can bookmark the direct URL), and pick one indexing-control mechanism instead of two conflicting ones: since the page requires authentication anyway, drop it from `robots.txt`'s disallow list and let the `noindex` meta tag (now enforceable, since crawling is allowed) plus the login wall do the job.

**Minimal code change (`Footer.tsx`):**
```tsx
<ul className="space-y-2 text-sm">
  <li><Link href="/" className="hover:text-white transition-colors">Today&apos;s Satta Results</Link></li>
  <li><Link href="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
  <li><Link href="/about" className="hover:text-white transition-colors">About Us</Link></li>
  {/* "Admin Panel" link removed */}
</ul>
```
**Minimal code change (`robots.ts`):**
```ts
disallow: ["/api/"], // "/add-game-value" removed — noindex + auth cover it now that it's unlinked
```

---

## Issue #4 — No custom `not-found.tsx` (404/410 handling)

**Severity:** Medium
**File:** missing — should be `src/app/not-found.tsx`
**Checklist items:** 11

**Exact problem:** There is no `not-found.tsx`, `error.tsx`, or `loading.tsx` anywhere under `src/app`. `notFound()` is correctly called for invalid game codes (once Issue #2 is fixed) and invalid years (`charts/[gameCode]/[year]/layout.tsx` already does this), so the HTTP status is correct (404) — but visitors and crawlers land on Next.js's bare, unbranded default 404 page with no navigation back into the site. Nothing in the codebase ever issues a 410 (Gone) — not necessarily wrong, since nothing here represents permanently-removed content, but worth knowing it isn't in the toolkit if you ever deliberately retire a URL (e.g., a discontinued game) and want to signal "gone for good" rather than "not found."

**Why it affects SEO/indexing:** A 404 without internal links is a dead end for both users and link-equity flow — anyone who lands on it (including Googlebot following a stale or malformed link) has nowhere to go but back. A branded 404 with links to `/`, `/charts`, `/about` keeps them on-site and gives crawlers a path back into your real content.

**Recommended fix:** Add `src/app/not-found.tsx` reusing `Header`/`Footer` with links to the main sections.

**Minimal code change:**
```tsx
// src/app/not-found.tsx
import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-2xl px-4 py-16 text-center">
      <h1 className="text-3xl font-black text-gray-900">Page not found</h1>
      <p className="mt-3 text-gray-600">The page you're looking for doesn't exist or may have moved.</p>
      <div className="mt-6 flex justify-center gap-4">
        <Link href="/" className="font-bold text-indigo-600 hover:underline">Home</Link>
        <Link href="/charts" className="font-bold text-indigo-600 hover:underline">Charts</Link>
      </div>
    </main>
  );
}
```
(`Header`/`Footer` render automatically since they live in `layout.tsx`, which wraps `not-found.tsx` too.)

---

## Issue #5 — Blog posts are orphaned once the archive grows past 12

**Severity:** Medium (grows to High as blog volume increases)
**Files:** `src/lib/blogs-mongodb.ts` (`.limit(12)` in `getPublishedBlogs`), `src/app/HomeClient.tsx` ("Latest Blogs" section), missing `src/app/blog/page.tsx`
**Checklist items:** 10, 21

**Exact problem:** `getPublishedBlogs()` caps at the 12 most recent posts, and that's the only source `HomeClient.tsx`'s "Latest Blogs" section renders from — there is no `src/app/blog/page.tsx` index/listing route at all. The *only* other place any blog post URL appears is `sitemap.ts`. Once you have more than 12 published posts, every post past the 12 most recent has exactly one discovery path (the sitemap) and zero in-site links pointing to it.

**Why it affects SEO/indexing:** Orphan pages (reachable only via sitemap, with no internal links) get a materially weaker signal of importance than linked pages, and are the classic profile of a page that sits in "Discovered – currently not indexed" indefinitely — Google knows it exists but has no link-graph reason to prioritize crawling it.

**Recommended fix:** Add a `/blog` index page listing all published posts (paginated once volume warrants it), linked from the header or footer, so every post has a durable, always-current internal link path independent of the homepage's 12-post window.

**Minimal code change:** New file `src/app/blog/page.tsx` that calls `getPublishedBlogs()` (or a paginated variant) and renders a simple grid of `<Link href={`/blog/${post.slug}`}>` cards — reuse the card markup already in `HomeClient.tsx`'s blog section rather than designing something new.

---

## Issue #6 — Templated fallback metadata for any chart page outside the curated list

**Severity:** Medium
**File:** `src/app/chart/[gameCode]/layout.tsx` (`generateMetadata`)
**Checklist items:** 6, 14

**Exact problem:** `CHART_META` hand-curates titles/descriptions for ~24 slugs. Anything else — including legitimate live-Mongo-derived games not in that dictionary (`kohlapur`, `manipur`, `up-bazar`, `palwal-city`, `mathura-city`, and any future game added only in the database) — falls back to a single template: `` `${name} Satta King Chart` `` / `` `Check the ${name} Satta King chart, daily results, old records, and complete chart history on Faridabad Satta.` ``. Every one of those pages will have near-identical title/description patterns differing only by the substituted name.

**Why it affects SEO/indexing:** Formulaic, low-differentiation titles and descriptions across many URLs are a duplicate/thin-content signal, and they also make for weak, generic-looking search snippets that get lower click-through even if indexed.

**Recommended fix:** Extend `CHART_META` to cover every game the site actually has a chart page for (including the custom-game keys and Mongo-sourced ones), so the fallback template becomes the rare exception rather than the default for a meaningful chunk of your chart pages. This ties directly into fixing Issue #2 — once you validate `gameCode` against a known list, that same list is the natural place to guarantee metadata coverage too.

---

## Issue #7 — Two small canonical/sitemap consistency nits

**Severity:** Low
**Files:** `src/app/sitemap.ts`, `src/app/layout.tsx`, `src/app/page.tsx`
**Checklist items:** 7, 9

**Exact problem:** The homepage's canonical tag (both `layout.tsx`'s default metadata and `page.tsx`'s `generateMetadata`) is `SITE_URL` with no trailing slash (`https://www.faridabadsatta.com`), but `sitemap.ts` lists the homepage as `` `${SITE_URL}/` `` — with a trailing slash. Every other static route in the sitemap matches its canonical exactly; the homepage is the one inconsistency.

**Why it affects SEO/indexing:** Low impact on its own — Google generally normalizes root-domain trailing slashes — but it's an easy, free fix toward "every URL Google sees for this page agrees with every other one," which is good hygiene and removes one more variable if you ever see homepage indexing behave oddly.

**Recommended fix:**
```ts
// src/app/sitemap.ts
{ url: SITE_URL, lastModified: now, changeFrequency: "hourly", priority: 1 }, // no trailing slash, matches canonical
```

---

## Issue #8 — Blog posts have no breadcrumb structured data; listing pages have no `ItemList`

**Severity:** Low
**Files:** `src/app/blog/[slug]/page.tsx`, `src/app/charts/page.tsx`
**Checklist items:** 15

**Exact problem:** `src/app/chart/[gameCode]/layout.tsx` and `src/app/charts/[gameCode]/[year]/layout.tsx` both emit a `BreadcrumbList` JSON-LD block. Blog posts don't — `blog/[slug]/page.tsx` only emits `BlogPosting`. Separately, `charts/page.tsx` renders a full grid of every game (and, for main games, every available year) purely as HTML links, with no `ItemList` structured data describing that collection.

**Why it affects SEO/indexing:** Breadcrumb rich results are a (minor but free) SERP real-estate and context win you're already getting on chart pages; there's no reason blog posts should be the exception. `ItemList` on `/charts` is a smaller, optional win — it helps Google understand the page is a structured collection rather than a wall of links, but has less direct payoff than the breadcrumb gap.

**Recommended fix:** Add the same `BreadcrumbList` pattern used in `chart/[gameCode]/layout.tsx` (Home → Blog → post title) to `blog/[slug]/page.tsx`. Treat `ItemList` on `/charts` as optional/future work.

---

## Issue #9 — No `next/image`, third-party scripts loaded outside `next/script`

**Severity:** Medium
**Files:** `src/app/HomeClient.tsx` (line ~449), `src/app/blog/[slug]/page.tsx` (line ~70), `src/app/layout.tsx` (GA scripts in `<head>`)
**Checklist items:** 16, 17, 20

**Exact problem:** Every image in the codebase is a raw `<img>` (`grep` for `next/image` across `src/` returns nothing) — no automatic `srcset`, no modern-format (WebP/AVIF) conversion, no built-in lazy-loading-with-`sizes`. The blog post cover image (`blog/[slug]/page.tsx`) is the likely LCP element on post pages and is unoptimized. Separately, Google Tag Manager is loaded via a raw `<script async src="https://www.googletagmanager.com/gtag/js...">` plus an inline `<script dangerouslySetInnerHTML>` directly in the root `<head>` (`layout.tsx`), rather than Next.js's `<Script>` component, which lets you control load priority (`strategy="afterInteractive"` or `"lazyOnload"`) and gets deduped/optimized by Next's script-loading machinery.

**Why it affects SEO/indexing:** LCP and CLS are both Core Web Vitals and both confirmed ranking signals; unoptimized, full-resolution images served without responsive variants directly hurt LCP on mobile connections, which is the majority of this site's likely traffic profile. Analytics scripts competing for main-thread time during page load affects INP (the CWV that replaced FID) — `async` alone helps but `next/script` with an explicit deferred strategy is the documented best practice specifically to keep third-party tags off the critical path.

**Recommended fix:** Swap the blog cover image (at minimum) to `next/image` with explicit `width`/`height`; since it's served from MongoDB GridFS via `/api/blog-images/[id]`, add that path pattern to `images.remotePatterns` in `next.config.ts`. Move the GTM scripts to `next/script` with `strategy="afterInteractive"`.

**Minimal code change (`layout.tsx`):**
```tsx
import Script from "next/script";
// ...
<Script async src="https://www.googletagmanager.com/gtag/js?id=G-W71W8KSGT4" strategy="afterInteractive" />
<Script id="ga-init" strategy="afterInteractive">
  {`window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());
    gtag('config', 'G-W71W8KSGT4');`}
</Script>
```

---

## Issue #10 — URL structure: `/chart/` vs `/charts/` split (informational, low priority)

**Severity:** Low
**Files:** `src/app/chart/[gameCode]/*`, `src/app/charts/[gameCode]/[year]/*`
**Checklist items:** 22

**Exact problem:** The current-window chart lives under singular `/chart/{game}`, while the yearly archive lives under plural `/charts/{game}/{year}` — two different route roots for what a visitor experiences as one feature ("this game's chart, current vs. archived"). Not a defect, just an inconsistency.

**Why it affects SEO/indexing:** Minimal direct impact — both are indexable, both have working canonicals. It's purely an information-architecture nit: a unified structure (e.g. `/charts/{game}` for current, `/charts/{game}/{year}` for archive) would consolidate the "charts" concept under one path segment and read more clearly in the URL bar and in search snippets.

**Recommended fix:** Not worth doing reactively — restructuring `/chart/*` to `/charts/*` now means mapping and 301-redirecting every existing indexed `/chart/{game}` URL, which is real migration risk for a cosmetic gain. Only worth considering if you're already planning a larger information-architecture pass.

---

## What's already solid (don't touch)

- **Redirects** (`next.config.ts`): all known alternate hosts (`faridabadsatta.com`, `a7satta.co`, `www.a7satta.co`) permanently (301) redirect to `www.faridabadsatta.com` — correct, avoids host-splitting duplicate content.
- **Canonical URLs**: consistent site-wide, all built from one `SITE_URL` constant (`src/lib/site.ts`) — no hardcoded-host drift anywhere.
- **`sitemap.ts`**: dynamic, merges a fixed game list with live Mongo data so it never goes empty on a cache miss, and — notably — **deliberately excludes** yearly archive pages that have no real records instead of publishing thin/empty URLs. This is genuinely better than most sites this size do, and is the model the fallback-metadata fix in Issue #6 should follow.
- **`robots.ts`**: correctly allows the specific read-only API routes the chart pages hydrate from while blocking the rest of `/api/` — a deliberate, sensible carve-out (see Issue #1's note: this becomes less necessary once those pages are server-rendered, but isn't wrong today).
- **Yearly-archive validation** (`charts/[gameCode]/[year]/layout.tsx`): correctly checks `gameCode` against `TOP_GAME_DEFS` and the year against a sane range, calling `notFound()` (with a `noindex` fallback) otherwise — this is the pattern Issue #2 needs replicated on the sibling route.
- **Heading structure**: one `<h1>` per page, logical nesting, no level-skipping found anywhere reviewed.
- **Structured data coverage**: `Organization`/`WebSite` graph site-wide, `BreadcrumbList` on chart and yearly-archive pages, full `BlogPosting` (with dates, author, publisher) on blog posts.
- **Homepage data fetching** (`src/app/page.tsx`): server-fetched via `getCachedHomeData()` before render, with client-side polling layered on top for freshness — this is the correct progressive-enhancement pattern, and exactly what Issue #1 needs the chart pages to match.

---

## A. Top 5 issues affecting Google indexing

1. **Issue #2** — `/chart/[gameCode]` accepts and indexes any arbitrary string (no allow-list) — the most likely single cause of broad "Discovered – currently not indexed" behavior across the domain.
2. **Issue #1** — Chart and yearly-archive pages ship empty server HTML; real content only appears after client-side fetches.
3. **Issue #3** — Admin panel linked from every page's footer while relying on conflicting robots.txt-disallow + noindex directives.
4. **Issue #5** — Blog posts beyond the most recent 12 have no internal link path (sitemap-only discovery).
5. **Issue #6** — Formulaic fallback metadata for any chart page outside the curated ~24-slug list.

## B. Exact files to modify

- `src/app/chart/[gameCode]/layout.tsx` — add allow-list validation (#2), extend `CHART_META` coverage (#6)
- `src/app/chart/[gameCode]/page.tsx` — convert to server component with initial server-fetched data (#1)
- `src/app/charts/[gameCode]/[year]/page.tsx` — convert to server component with initial server-fetched data (#1)
- `src/components/layout/Footer.tsx` — remove the `/add-game-value` link (#3)
- `src/app/robots.ts` — remove `/add-game-value` from `disallow` (#3)
- `src/app/not-found.tsx` — new file, branded 404 (#4)
- `src/app/blog/page.tsx` — new file, blog index/listing (#5)
- `src/app/blog/[slug]/page.tsx` — add `BreadcrumbList` JSON-LD (#8)
- `src/app/sitemap.ts` — drop the homepage's trailing slash (#7)
- `src/app/layout.tsx` — move GTM scripts to `next/script` (#9)
- `next.config.ts` — add `images.remotePatterns` for the blog-image API route (#9)

## C. Recommended order of fixes

1. Issue #3 (footer link + robots.txt) — smallest, zero-risk change, immediately stops the conflicting-directive problem and the public admin-link exposure.
2. Issue #2 (gameCode allow-list) — closes the unbounded-URL-space hole; do this before anything else that touches chart pages so you're not server-rendering content for junk slugs too.
3. Issue #1 (SSR for chart pages) — the highest-effort, highest-payoff change; do it once #2 means you're only ever rendering real games.
4. Issue #6 (metadata coverage) — natural follow-on once #2's allow-list exists.
5. Issue #4 (not-found.tsx) — quick, independent.
6. Issue #5 (blog index page) — independent, do whenever convenient.
7. Issue #7, #8, #9 — low/medium, no dependencies, batch whenever convenient.

## D. Safe implementation plan

- Work on a feature branch (or at minimum a build you can diff against `main`) — none of this should go straight to the production PM2 process.
- Do Issue #3 first and deploy it alone — it's a pure removal/config change with no rendering-logic risk, easy to verify, and immediately reduces exposure.
- For Issue #2, add the allow-list check but log (don't silently 404) any slug it rejects for the first few days after deploy, so you can confirm no *legitimate* live-Mongo game name is being caught by the new check before you're confident the list is complete.
- For Issue #1, convert one route at a time (`/chart/[gameCode]` first, then `/charts/[gameCode]/[year]`), and keep the existing `/api/game-chart` / `/api/year-chart` endpoints untouched — they're still needed for client-side month/year navigation beyond the initial server-rendered view, so this is additive (add server-side data fetching) rather than a rip-and-replace of the API layer.
- After each deploy, spot-check a handful of real chart URLs with "view page source" (not the rendered DOM) to confirm the table data is actually present in the raw HTML — that's the concrete signal Issue #1 is fixed.
- Don't change `robots.ts`'s allowances for the chart-data API routes until you've confirmed the SSR conversion is stable in production — there's no rush to remove them, and they're harmless to leave in place.

## E. Commands to test the changes locally

```bash
# install & run dev server
npm install
npm run dev

# confirm chart pages now ship real HTML server-side (should show table data, not just a skeleton)
curl -s http://localhost:3000/chart/faridabad | grep -A2 "font-mono"

# confirm the gameCode allow-list rejects junk (should 404 after Issue #2's fix)
curl -sI http://localhost:3000/chart/this-is-not-a-real-game | head -1

# confirm the admin link is gone from rendered footer HTML
curl -s http://localhost:3000/ | grep -c "add-game-value"   # expect 0

# confirm production build succeeds (catches type errors, SSR/client-boundary mistakes)
npm run build

# spot-check robots.txt and sitemap.xml output
curl -s http://localhost:3000/robots.txt
curl -s http://localhost:3000/sitemap.xml | head -50

# lint
npm run lint
```

## F. Production deployment checklist

- [ ] `npm run build` succeeds locally with zero type errors before touching the VPS.
- [ ] Diff `robots.ts` output (`/robots.txt`) and confirm `/add-game-value` is no longer disallowed but `/api/` still is.
- [ ] Confirm `/add-game-value` still requires login and returns `noindex` in its response headers/meta even though it's no longer in `robots.txt`.
- [ ] View-source (not DevTools rendered view) on a live `/chart/{game}` and `/charts/{game}/{year}` page post-deploy to confirm table data is in the raw HTML.
- [ ] Hit a deliberately-invalid `/chart/{junk}` URL on production and confirm it 404s.
- [ ] Confirm the footer no longer renders an "Admin Panel" link on any page.
- [ ] Re-submit `sitemap.xml` in Google Search Console after deploy (not required for it to be picked up, but speeds up re-crawl of the changed pages).
- [ ] In Search Console, watch the "Page indexing" report over the following 1–2 weeks specifically for movement in "Discovered – currently not indexed" and "Crawled – currently not indexed" counts — that's your confirmation signal that Issues #1 and #2 actually moved the needle.
- [ ] Restart the PM2 process (`pm2 restart <app-name>` or your deploy script's equivalent) and confirm it comes back up cleanly with `pm2 logs`.
- [ ] Keep the current `robots.ts` API allowances in place for at least one full deploy cycle after the SSR conversion, in case any client-side paging logic still depends on them.
